function [] = animatePend(time, x_vec, th_vec,plot_title)

figure

FPS = 20; % frames per second
t_anim = 0:(1/FPS):max(time); % all the time points of each frame
th_anim = interp1(time, th_vec, t_anim);
x_anim = interp1(time, x_vec, t_anim);
pause(1)
% Draw Block
block_x = [-0.5, -0.5, 0.5, 0.5];
block_y = [0, 0.5, 0.5, 0];

for iter = 1:numel(t_anim)
    % Translate Cart
    fill(block_x + x_anim(iter), block_y,'r')
    hold on
    
    % Swing pendulum
    plot([0 sin(th_anim(iter))]+x_anim(iter), [0 -cos(th_anim(iter))],'k-')
    hold off
    
    axis equal
    axis([-2 7 -2 2])
    title(plot_title)
    xlabel('x')
    drawnow
end



