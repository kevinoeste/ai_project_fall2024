function dq = dynamics(t, q, params,OPdx,OPth,OPdth,OPF)

n = numel(q); % count the size of q

% bring in parameters
T=params.T;
N=params.N;
m1=params.m1;
b=params.b;
L=params.L;
g=params.g;
m2=params.m2;
F = params.F

% This will make our dynamics function work for
% BOTH defining our defect constraints AND
% simulating our dynamics with ODE45

x = q(1:n./4); % x
dx = q(n./4+1:2.*n./4); % y
th = q(2.*n./4+1:3.*n./4); % th
dth = q(3.*n./4+1:4.*n./4); % v


 % if(n == 4) % it's NOT being called for defect constraints
 %    % interpolate our force at the current time
 %    F = interp1(linspace(0,T,N),F,t);
 % end

% Operating points
dxo = OPdx;
tho = OPth; 
dtho = OPdth;

Fo = OPF;

% Linearized about operating points
dq1 = dx;
dq2 = (3.*L.*g.*m2.*cos(tho).*sin(tho))./(4.*L.*m1 + 4.*L.*m2 - 3.*L.*m2.*cos(tho).^2) - (4.*((L.*m2.*sin(tho).*dtho.^2)./2 - Fo + b.*dxo))./(4.*m1 + 4.*m2 - 3.*m2.*cos(tho).^2) + ...
     (-(4.*b)./(4.*m1 + 4.*m2 - 3.*m2.*cos(tho).^2)).*(dx-dxo) + ...
     ((24.*m2.*cos(tho).*sin(tho).*((L.*m2.*sin(tho).*dtho.^2)./2 - Fo + b.*dxo))./(4.*m1 + 4.*m2 - 3.*m2.*cos(tho).^2).^2 - (2.*L.*dtho.^2.*m2.*cos(tho))./(4.*m1 + 4.*m2 - 3.*m2.*cos(tho).^2) - (3.*L.*g.*m2.*sin(tho).^2)./(4.*L.*m1 + 4.*L.*m2 - 3.*L.*m2.*cos(tho).^2) + (3.*L.*g.*m2.*cos(tho).^2)./(4.*L.*m1 + 4.*L.*m2 - 3.*L.*m2.*cos(tho).^2) - (18.*L.^2.*g.*m2.^2.*cos(tho).^2.*sin(tho).^2)./(4.*L.*m1 + 4.*L.*m2 - 3.*L.*m2.*cos(tho).^2).^2).*(th-tho) + ...
     (-(4.*L.*dtho.*m2.*sin(tho))./(4.*m1 + 4.*m2 - 3.*m2.*cos(tho).^2)).*(dth-dtho) + ...
     (4./(4.*m1 + 4.*m2 - 3.*m2.*cos(tho).^2)).*(F-Fo);
dq3 = dth;
dq4 = (6.*cos(tho).*((L.*m2.*sin(tho).*dtho.^2)./2 - Fo + b.*dxo))./(4.*L.*m1 + 4.*L.*m2 - 3.*L.*m2.*cos(tho).^2) - (6.*L.*g.*m2.*sin(tho).*(m1 + m2))./(4.*L.^2.*m2.^2 - 3.*L.^2.*m2.^2.*cos(tho).^2 + 4.*L.^2.*m1.*m2) + ...
     ((6.*b.*cos(tho))./(4.*L.*m1 + 4.*L.*m2 - 3.*L.*m2.*cos(tho).^2)).*(dx-dxo) + ...
     ((3.*L.*dtho.^2.*m2.*cos(tho).^2)./(4.*L.*m1 + 4.*L.*m2 - 3.*L.*m2.*cos(tho).^2) - (6.*sin(tho).*((L.*m2.*sin(tho).*dtho.^2)./2 - Fo + b.*dxo))./(4.*L.*m1 + 4.*L.*m2 - 3.*L.*m2.*cos(tho).^2) - (6.*L.*g.*m2.*cos(tho).*(m1 + m2))./(4.*L.^2.*m2.^2 - 3.*L.^2.*m2.^2.*cos(tho).^2 + 4.*L.^2.*m1.*m2) - (36.*L.*m2.*cos(tho).^2.*sin(tho).*((L.*m2.*sin(tho).*dtho.^2)./2 - Fo + b.*dxo))./(4.*L.*m1 + 4.*L.*m2 - 3.*L.*m2.*cos(tho).^2).^2 + (36.*L.^3.*g.*m2.^3.*cos(tho).*sin(tho).^2.*(m1 + m2))./(4.*L.^2.*m2.^2 - 3.*L.^2.*m2.^2.*cos(tho).^2 + 4.*L.^2.*m1.*m2).^2).*(th-tho) + ...
     ((6.*L.*dtho.*m2.*cos(tho).*sin(tho))./(4.*L.*m1 + 4.*L.*m2 - 3.*L.*m2.*cos(tho).^2)).*(dth-dtho) + ...
     (-(6.*cos(tho))./(4.*L.*m1 + 4.*L.*m2 - 3.*L.*m2.*cos(tho).^2)).*(F-Fo);


dq = [dq1; dq2; dq3; dq4];
