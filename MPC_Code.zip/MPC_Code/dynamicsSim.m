function dq = dynamicsSim(t, q, params)

n = numel(q); % count the size of q

% bring in parameters
T=params.T;
N=params.N;
m1=params.m1;
b=params.b;
L=params.L;
g=params.g;
m2=params.m2;
F = params.F;

% This will make our dynamics function work for
% BOTH defining our defect constraints AND
% simulating our dynamics with ODE45

x = q(1:n/4); % x
dx = q(n/4+1:2*n/4); % y
th = q(2*n/4+1:3*n/4); % th
dth = q(3*n/4+1:4*n/4); % v


 if(n == 4) % it's NOT being called for defect constraints
    % interpolate our force/torque at the current time
    F = interp1(linspace(0,T,N),F,t);
 end



% Nonlinearized Equations
dq1 = dx;
dq2 = (3*L*g*m2.*cos(th).*sin(th))./(4*L*m1 + 4*L*m2 - 3*L*m2.*cos(th).^2) - (4*((L*m2.*sin(th).*dth.^2)./2 - F + b.*dx))./(4*m1 + 4*m2 - 3*m2.*cos(th).^2);
dq3 = dth;
dq4 = (6.*cos(th).*((L*m2.*sin(th).*dth.^2)./2 - F + b.*dx))./(4*L*m1 + 4*L*m2 - 3*L*m2.*cos(th).^2) - (6*L*g*m2.*sin(th).*(m1 + m2))./(4*L^2*m2^2 - 3*L^2*m2^2.*cos(th).^2 + 4*L^2*m1*m2);


dq = [dq1; dq2; dq3; dq4];