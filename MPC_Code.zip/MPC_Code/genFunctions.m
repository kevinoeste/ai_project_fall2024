% genFunctions
% This generates functions that can create
% our key matrices for optimization on-the-fly

% Create the following
% Hmat, fmat, Amat, bmat, Aeqmat, beqmat
% These will take in key parameters and our design vector
% and return the relevant matrices

% Anything that might change on-the-fly
% we will want to be inputs to these functions

syms Fmax Fmin 
syms x dx th dth F [N 1]
syms Wx Wdx Wth Wdth WF
syms xcur dxcur thcur dthcur 
syms OPdx OPth OPdth OPF [N-1 1]
syms xdes dxdes thdes dthdes 

% Current states
qcur = [xcur; dxcur; thcur; dthcur];

% Design vector
%  z = [x; dx; th; dth; F]

% Define our cost function
dt = T/(N-1);
term1 = Wx*(x-xdes).^2 + Wdx*(dx-dxdes).^2 + Wth*(th-thdes).^2 + Wdth*(dth-dthdes).^2;
term2 = WF*F.^2;
% Objective Function minimize position and effort
J = sum(term1(1:end-1) + term2(1:end-1))*dt; 

% Define inequality constraints
cineq = [F - Fmax; -F + Fmin];

params.F = F(1:end-1);

% Define equality constraints
% These will be defect contraints
ceq = [x(2:end);dx(2:end);th(2:end);dth(2:end)] - ...
    [x(1:end-1);dx(1:end-1);th(1:end-1);dth(1:end-1)] - ...
    dynamics(0,[x(1:end-1);dx(1:end-1);th(1:end-1);dth(1:end-1)], ...
    params,OPdx,OPth,OPdth,OPF)*dt;

ceq(end+1:end+4) = [x(1)-xcur; dx(1)-dxcur; th(1)-thcur; dth(1)-dthcur];

% Design vector
z = [x; dx; th; dth; F];

% Computing our Hessians and Gradients of the Objective Function
H = hessian(J,z);
f = jacobian(J,z);
f = subs(f,z, zeros(size(z)));

A = jacobian(cineq,z);
b = -subs(cineq,z, zeros(size(z)));

Aeq = jacobian(ceq,z);
beq = -subs(ceq, z, zeros(size(z)));

qdes = [xdes; dxdes; thdes; dthdes];
matlabFunction(H, 'file', 'Hmat', 'Vars', {qdes,qcur,WF,Wdth,Wdx,Wth,Wx});
matlabFunction(f, 'file', 'fmat', 'Vars', {qdes,qcur,WF,Wdth,Wdx,Wth,Wx});
matlabFunction(A, 'file', 'Amat', 'Vars', {qdes,qcur});
matlabFunction(b, 'file', 'bmat', 'Vars', {qdes,qcur,Fmax,Fmin});
% Aeq & beq matrices require operating point as input
matlabFunction(Aeq, 'file', 'Aeqmat', 'Vars', {qdes,qcur, OPdx,OPth,OPdth,OPF});
matlabFunction(beq, 'file', 'beqmat', 'Vars', {qdes,qcur, OPdx,OPth,OPdth,OPF});