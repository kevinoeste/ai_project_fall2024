% main.m
% Run MPC on pendulum on cart

clc
clear
close all

% Define our MPC Parameters
T = 1; % Planning horizon
N = 51; % Number of Nodes
Ts = 0.1; % Sample Time

Wx = 100;
Wdx = 10;
Wth = 100;
Wdth = 100;

WF = 0;
% q = [x;dx;th;dth]
% u = F

% Define Parameters
m1 = 2; % cart mass [kg]
b = 0.5; % damping
L = 1; % pendulum length [m]
g = 10; % gravity [m/s^2]
m2 = .1; % pendulum mass [kg]

% Create parameters structure
params.T = T;
params.N = N;
params.m1 = m1;
params.b = b;
params.L = L;
params.g = g;
params.m2 = m2;

% Generate functions that compute our key matrices
% for the QP
% tic
% genFunctions
% toc 
% keyboard

qinit = [0; 0; pi; 0]; % initial state
qdes = [5; 0; pi; 0]; % desired state

% Input Limits
Fmin = -10;
Fmax = 10;
     
% MPC Loop
%  1. Sample the state of the system
%  2. Run a TO (QP, quadprog)
%  3. Simulate for Ts using the optimized inputs

done = false;

% q = [x; y; th; v; w]


t_cur = 0; % current time

t_sim = 10; % simulation time

qcur = qinit;
%  z = [x; dx; th; dth; F]

OPdx = qcur(2)*ones(N-1,1);
OPth = qcur(3)*ones(N-1,1);
OPdth = qcur(4)*ones(N-1,1);
OPF = 0*ones(N-1,1);

while ~done

    % Trajectory Optimization
    [opt_vec, J] = quadprog(Hmat(qdes,qcur,WF,Wdth,Wdx,Wth,Wx), ...
        fmat(qdes,qcur,WF,Wdth,Wdx,Wth,Wx), ...
        Amat(qdes,qcur), ...
        bmat(qdes,qcur,Fmax,Fmin), ...
        Aeqmat(qdes,qcur,OPdx,OPth,OPdth,OPF), ...
        beqmat(qdes,qcur,OPdx,OPth,OPdth,OPF));
    
    % Simulate (using ode45)
    params.F = opt_vec(4*N+1:5*N); % 5th set of variables (1:N)
    
    % Choose to simulate using Nonlinear dynamics
    dynamics2 = @(t,y) dynamicsSim(t,y,params); % Nonlinear
    [t_vec, q_vec] = ode45(dynamics2, [0 Ts], qcur);

    qcur = q_vec(end,:).'; % Update current state

dxo = opt_vec(1*N+2:2*N);
tho = opt_vec(2*N+2:3*N);
dtho = opt_vec(3*N+2:4*N);
Fo = opt_vec(4*N+2:5*N);

    t_cur = t_cur + Ts;
    if(t_cur > t_sim)
        done = true;
    end
%% Animation
    % Draw cart
    block_x = [-0.5, -0.5, 0.5, 0.5];
    block_y = [0, 0.5, 0.5, 0];

    % Translate Cart
    fill(block_x + qcur(1), block_y,'r')
    hold on
    
    % Swing pendulum
    plot([0 sin(qcur(3))]+qcur(1), [0 -cos(qcur(3))],'k-')
    hold off
    
    axis equal
    axis([-2 7 -2 2])
    title("MPC Pendulum on Cart")
    xlabel('x [m]')
    drawnow
    
end
